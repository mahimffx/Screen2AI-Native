#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle command not found. Open this project in Code on the Go and use its Build/Run action, or install/configure its build tools first." >&2
  exit 127
fi
exec gradle :app:assembleDebug "$@"
