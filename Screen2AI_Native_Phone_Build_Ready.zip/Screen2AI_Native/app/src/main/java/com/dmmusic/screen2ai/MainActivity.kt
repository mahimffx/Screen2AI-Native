package com.dmmusic.screen2ai

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var start: Button
    private lateinit var stop: Button
    private lateinit var export: Button
    private val projectionManager by lazy { getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    private var pendingProjectionCode = 0
    private var pendingProjectionData: Intent? = null

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            pendingProjectionCode = result.resultCode
            pendingProjectionData = result.data
            if (!Settings.canDrawOverlays(this)) {
                status.text = "Floating Control ব্যবহারের জন্য Display over other apps অনুমতি দাও।"
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else startCaptureService()
        } else status.text = "Screen Capture অনুমতি দেওয়া হয়নি।"
    }

    private val createZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) writeZipTo(uri)
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val n = intent?.getIntExtra(CaptureService.EXTRA_COUNT, 0) ?: 0
            count.text = n.toString()
            export.isEnabled = n > 0
            status.text = intent?.getStringExtra(CaptureService.EXTRA_STATUS) ?: "ক্যাপচার চলছে"
            val live = intent?.getBooleanExtra(CaptureService.EXTRA_LIVE, false) ?: false
            start.isEnabled = !live
            stop.isEnabled = live
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.statusText); count = findViewById(R.id.frameCount)
        start = findViewById(R.id.startButton); stop = findViewById(R.id.stopButton); export = findViewById(R.id.exportButton)
        start.setOnClickListener { projectionLauncher.launch(projectionManager.createScreenCaptureIntent()) }
        stop.setOnClickListener { sendControl(CaptureService.ACTION_STOP) }
        export.setOnClickListener { createZip.launch("Screen2AI_Project.zip") }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 91)
        val filter = IntentFilter(CaptureService.ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, filter)
        refreshCount()
    }

    override fun onResume() {
        super.onResume()
        if (pendingProjectionData != null && Settings.canDrawOverlays(this)) startCaptureService()
    }

    private fun startCaptureService() {
        val data = pendingProjectionData ?: return
        val intent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, pendingProjectionCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        pendingProjectionData = null
        status.text = "ক্যাপচার সার্ভিস চালু হচ্ছে…"
    }

    private fun sendControl(action: String) { startService(Intent(this, CaptureService::class.java).setAction(action)) }

    private fun refreshCount() {
        val dir = getExternalFilesDir("captures") ?: return
        val latest = dir.listFiles()?.maxByOrNull { it.lastModified() }
        val n = latest?.listFiles { f -> f.extension.equals("jpg", true) }?.size ?: 0
        count.text = n.toString(); export.isEnabled = n > 0
    }

    private fun writeZipTo(uri: Uri) {
        try {
            val root = getExternalFilesDir("captures") ?: error("Storage unavailable")
            val session = root.listFiles()?.filter { it.isDirectory }?.maxByOrNull { it.lastModified() } ?: error("কোনো frame পাওয়া যায়নি")
            val images = session.listFiles { f -> f.extension.equals("jpg", true) }?.sortedBy { it.name } ?: emptyList()
            contentResolver.openOutputStream(uri)?.use { raw -> ZipOutputStream(raw).use { zip ->
                images.forEach { file -> zip.putNextEntry(ZipEntry("frames/${file.name}")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry() }
                val timeline = buildString {
                    append("{\n  \"session\": \"").append(session.name).append("\",\n  \"frame_count\": ").append(images.size).append(",\n  \"frames\": [\n")
                    images.forEachIndexed { i, f -> append("    {\"frame\": \"frames/${f.name}\", \"time_sec\": ").append((f.lastModified() - (session.name.removePrefix("session_").toLongOrNull() ?: session.lastModified())).coerceAtLeast(0) / 1000.0).append("}").append(if (i == images.lastIndex) "\n" else ",\n") }
                    append("  ]\n}\n")
                }
                addText(zip, "timeline.json", timeline)
                addText(zip, "SPEC.md", "# Screen2AI Capture\n\nSession: ${session.name}\n\n## Frames\n${images.joinToString("\n") { "- frames/${it.name}" }}\n")
                addText(zip, "AI_PROMPT.md", "You are an expert app developer. Analyze the supplied screenshots in chronological order. Describe the visible UI, layout, colors, typography, navigation, controls, and interactions. State assumptions where evidence is incomplete. Create an original implementation; do not copy protected logos or artwork.\n")
            } }
            status.text = "ZIP Export সম্পন্ন হয়েছে।"
        } catch (e: Exception) { status.text = "ZIP তৈরি হয়নি: ${e.message}" }
    }

    private fun addText(zip: ZipOutputStream, name: String, text: String) { zip.putNextEntry(ZipEntry(name)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry() }

    override fun onDestroy() { try { unregisterReceiver(receiver) } catch (_: Exception) {}; super.onDestroy() }
}
