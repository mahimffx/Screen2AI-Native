package com.dmmusic.screen2ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.math.abs

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.dmmusic.screen2ai.START"
        const val ACTION_STOP = "com.dmmusic.screen2ai.STOP"
        const val ACTION_PAUSE = "com.dmmusic.screen2ai.PAUSE"
        const val ACTION_RESUME = "com.dmmusic.screen2ai.RESUME"
        const val ACTION_UPDATE = "com.dmmusic.screen2ai.UPDATE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_COUNT = "count"
        const val EXTRA_STATUS = "status"
        const val EXTRA_LIVE = "live"
        private const val CHANNEL = "screen2ai_capture"
        private const val NOTIFICATION_ID = 2201
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private var overlay: View? = null
    private var paused = false
    private var frameCount = 0
    private var previousSignature: IntArray? = null
    private var sessionDir: File? = null
    private var lastCapture = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> stopCapture()
            ACTION_PAUSE -> { paused = true; updateOverlay("▶ Resume", ACTION_RESUME); broadcast("Paused") }
            ACTION_RESUME -> { paused = false; updateOverlay("Ⅱ Pause", ACTION_PAUSE); broadcast("ক্যাপচার চলছে") }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun startCapture(intent: Intent) {
        if (projection != null) return
        createChannel()
        startForeground(NOTIFICATION_ID, notification("স্ক্রিন ক্যাপচার চলছে"))
        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (data == null) { stopSelf(); return }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopCapture() } }, Handler(mainLooper))
            val metrics = DisplayMetrics()
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels; val height = metrics.heightPixels; val density = metrics.densityDpi
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            worker = HandlerThread("Screen2AIFrames").also { it.start() }; handler = Handler(worker!!.looper)
            sessionDir = File(getExternalFilesDir("captures"), "session_${System.currentTimeMillis()}").apply { mkdirs() }
            reader!!.setOnImageAvailableListener({ source -> if (!paused) processImage(source) }, handler)
            virtualDisplay = projection!!.createVirtualDisplay("Screen2AI", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            showOverlay(); broadcast("ক্যাপচার চলছে")
        } catch (e: Exception) { broadcast("Capture error: ${e.message}"); stopCapture() }
    }

    private fun processImage(source: ImageReader) {
        val image = try { source.acquireLatestImage() } catch (_: Exception) { null } ?: return
        image.use { img ->
            val now = System.currentTimeMillis(); if (now - lastCapture < 650) return
            val bitmap = imageToBitmap(img) ?: return
            val sig = signature(bitmap)
            val old = previousSignature
            val changed = old == null || sig.indices.sumOf { abs(sig[it] - old[it]) } / sig.size >= 5
            if (changed) {
                val file = File(sessionDir, "frame_${(frameCount + 1).toString().padStart(4, '0')}.jpg")
                FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
                previousSignature = sig; frameCount++; lastCapture = now
                broadcast("ক্যাপচার চলছে — ${frameCount}টি ফ্রেম")
            }
            bitmap.recycle()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]; val buffer: ByteBuffer = plane.buffer
            val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
            val paddedWidth = rowStride / pixelStride
            val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            buffer.rewind(); padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            if (cropped === padded) cropped else { padded.recycle(); cropped }
        } catch (_: Exception) { null }
    }

    private fun signature(bitmap: Bitmap): IntArray {
        val small = Bitmap.createScaledBitmap(bitmap, 24, 24, true)
        val pixels = IntArray(576); small.getPixels(pixels, 0, 24, 0, 0, 24, 24); small.recycle()
        return pixels.map { (((it shr 16) and 255) * 3 + ((it shr 8) and 255) * 6 + (it and 255)) / 10 }.toIntArray()
    }

    @Suppress("DEPRECATION")
    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this) || overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = TextView(this).apply { text = "● REC · tap / hold"; textSize = 14f; setTextColor(0xFFFFFFFF.toInt()); setPadding(24, 16, 24, 16); setBackgroundColor(0xEE263A68.toInt()) }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 220 }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var downAt = 0L
        button.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; downAt = System.currentTimeMillis(); true }
                MotionEvent.ACTION_MOVE -> { params.x = startX - (event.rawX - downX).toInt(); params.y = startY + (event.rawY - downY).toInt(); wm.updateViewLayout(button, params); true }
                MotionEvent.ACTION_UP -> { if (abs(event.rawX - downX) < 10 && abs(event.rawY - downY) < 10) { if (System.currentTimeMillis() - downAt >= 850) send(ACTION_STOP) else if (paused) send(ACTION_RESUME) else send(ACTION_PAUSE) }; true }
                else -> true
            }
        }
        wm.addView(button, params); overlay = button
    }

    private fun updateOverlay(label: String, action: String) { (overlay as? TextView)?.text = if (action == ACTION_RESUME) "▶ RESUME" else "Ⅱ PAUSE" }

    private fun removeOverlay() { try { if (overlay != null) (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(overlay) } catch (_: Exception) {}; overlay = null }

    private fun stopCapture() {
        removeOverlay()
        try { virtualDisplay?.release() } catch (_: Exception) {}; virtualDisplay = null
        try { reader?.close() } catch (_: Exception) {}; reader = null
        try { projection?.stop() } catch (_: Exception) {}; projection = null
        worker?.quitSafely(); worker = null; handler = null
        broadcast("ক্যাপচার বন্ধ — মোট ${frameCount}টি ফ্রেম")
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun send(action: String) { startService(Intent(this, CaptureService::class.java).setAction(action)) }
    private fun broadcast(message: String) { sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra(EXTRA_COUNT, frameCount).putExtra(EXTRA_STATUS, message).putExtra(EXTRA_LIVE, projection != null)) }

    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val nm = getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen2AI Capture", NotificationManager.IMPORTANCE_LOW)) } }
    @Suppress("DEPRECATION")
    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL).setContentTitle("Screen2AI").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_camera).setContentIntent(open).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("Screen2AI").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_camera).setContentIntent(open).build()
    }

    override fun onDestroy() { removeOverlay(); try { virtualDisplay?.release(); reader?.close(); projection?.stop(); worker?.quitSafely() } catch (_: Exception) {}; super.onDestroy() }
}
