# Screen2AI v1.0 — Native Android Project (Phone Build Package)

এটি Kotlin-ভিত্তিক Native Android Studio project। এটি Website ZIP নয়; ZIP-to-APK converter-এ `index.html` খোঁজার জন্য বানানো হয়নি।

## এই প্যাকেজে সংশোধন
- আগের Kotlin source ও project folder structure রাখা হয়েছে।
- Manifest থেকে duplicate `POST_NOTIFICATIONS` permission সরানো হয়েছে।
- Java/Kotlin target 17 স্পষ্টভাবে সেট করা হয়েছে।
- Gradle 8.9 distribution metadata যোগ করা হয়েছে (AGP 8.7.3-এর সঙ্গে সামঞ্জস্যপূর্ণ)।
- `build-phone.sh` helper যোগ করা হয়েছে; IDE terminal-এ Gradle command থাকলে Debug APK build করবে।
- `local.properties.example` ও `.gitignore` যোগ করা হয়েছে।

## ফোনে Build করার পদ্ধতি (Code on the Go)
1. Code on the Go ইনস্টল করো: https://www.appdevforall.org/code-on-the-go/
2. অ্যাপের প্রথমবারের toolchain/SDK setup সম্পন্ন করো। প্রথম setup ও dependency download-এর জন্য ইন্টারনেট লাগতে পারে।
3. ZIP Extract করে `Screen2AI_Native` folder-টি Code on the Go-তে Project হিসেবে Open/Import করো। ZIP-টি ZIP-to-APK converter-এ দেবে না।
4. Project sync/build configuration সম্পন্ন হতে দাও। `compileSdk 35` platform এবং build tools ইনস্টল থাকতে হবে।
5. Build/Run থেকে `:app:assembleDebug` চালাও। অথবা IDE terminal-এ `sh build-phone.sh` চালাও, যদি `gradle` command PATH-এ থাকে।
6. সফল হলে APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ পাওয়া যাবে।
7. APK-টি ফোনে install করে permissions দিয়ে বাস্তবে পরীক্ষা করো।

## Offline Build সম্পর্কে
প্রথমবারের setup-এ Android SDK, Gradle distribution, Android Gradle Plugin, Kotlin plugin এবং AndroidX dependencies cache-এ আনতে হবে। সবগুলো cache-এ আসার পর Code on the Go-এর offline mode/Gradle offline option দিয়ে পুনরায় build চেষ্টা করা যাবে। কোনো dependency cache-এ না থাকলে Offline build ব্যর্থ হবে।

## Wrapper নোট
এই ZIP-এ Gradle wrapper distribution properties আছে; তবে official `gradle-wrapper.jar` binary অন্তর্ভুক্ত করা হয়নি। Code on the Go-এর IDE build flow ব্যবহার করো; এটি তার নিজস্ব Gradle tooling দিয়ে project build করতে পারে। `build-phone.sh` official Gradle Wrapper নয়—এটি IDE terminal-এ থাকা `gradle` command-কে কল করে।

## সোর্স ফিচার
- Kotlin Native Android application (WebView নয়)
- Android MediaProjection permission flow
- MediaProjection foreground service
- ImageReader frame capture
- visual-change-based screenshot collection
- movable system overlay controller
- AI-ready ZIP export: `frames/`, `timeline.json`, `SPEC.md`, `AI_PROMPT.md`

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই পরিবেশে Android SDK/Gradle build চালানো হয়নি; তাই APK compile বা phone-test সফল হয়েছে বলে দাবি করা হচ্ছে না।
- এই implementation continuous video recorder নয়; visual change হলে screenshot frame নেয়।
- Protected/DRM/secure screens capture নাও হতে পারে।
- Android-এর screen-capture consent ও overlay permission ব্যবহারকারীকে নিজে দিতে হবে।
- বাস্তব ফোনে Android version ও manufacturer background restrictions অনুযায়ী পরীক্ষা প্রয়োজন।

Package: `com.dmmusic.screen2ai`
